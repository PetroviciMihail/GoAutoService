import firebase from "firebase/compat/app";
import "firebase/compat/auth";
import "firebase/compat/firestore";
import { getStorage, ref, getDownloadURL } from "firebase/storage";
import {
  collection,
  query,
  where,
  getDocs,
  getDoc,
  setDoc,
  doc,
  onSnapshot,
} from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyDDJZ2orv-uKDP5_ICZY4qxBBkL-J-BzS0",
  authDomain: "goautoservice-99a07.firebaseapp.com",
  projectId: "goautoservice-99a07",
  storageBucket: "goautoservice-99a07.appspot.com",
  messagingSenderId: "944489682703",
  appId: "1:944489682703:web:98035ce9d430229310d07a",
  measurementId: "G-DF7ZTXEFWV",
};

let app;

if (firebase.apps.length === 0) {
  app = firebase.initializeApp(firebaseConfig);
} else {
  app = firebase.app();
}

const getCars = async (owner) => {
  const q = query(collection(db, "Cars"), where("owner", "==", owner));

  var newdata = [];
  const querySnapshot = await getDocs(q);

  for (const doc of querySnapshot.docs) {
    var itemdata = doc.data();

    newdata = [...newdata, itemdata];
  }
  //console.log("log din firebase api");
  console.log(newdata);
  return newdata;
};

const getRequests = async (owner) => {
  const q = query(
    collection(db, "ServiceRequests"),
    where("owner", "==", owner)
  );

  var newdata = [];
  const querySnapshot = await getDocs(q);

  for (const doc of querySnapshot.docs) {
    var itemdata = doc.data();
    if (itemdata.scheduled === false) newdata = [...newdata, itemdata];
  }
  //console.log("log din firebase api");
  //console.log(newdata);
  return newdata;
};

const getRequestsScheduled = async (owner) => {
  const q = query(
    collection(db, "ServiceRequests"),
    where("owner", "==", owner)
  );

  var newdata = [];
  const querySnapshot = await getDocs(q);

  for (const doc of querySnapshot.docs) {
    var itemdata = doc.data();
    if (
      itemdata.scheduled === true &&
      itemdata.done === false &&
      itemdata.canceled === false
    )
      newdata = [...newdata, itemdata];
  }
  //console.log("log din firebase api");
  //console.log(newdata);
  return newdata;
};

const getRequestOffers = async (docName) => {
  const q = query(collection(db, "ServiceRequests", docName, "Offers"));
  var newdata = [];
  const querySnapshot = await getDocs(q);
  for (const doc of querySnapshot.docs) {
    var itemdata = doc.data();
    newdata = [...newdata, itemdata];
  }
  console.log("log din firebase api request details");
  console.log(newdata);
  return newdata;
};
const getServiceDetails = async (serviceMail) => {
  const q = query(
    collection(db, "ServiceAccountsDetails"),
    where("owner", "==", serviceMail)
  );

  var newdata = [];
  const querySnapshot = await getDocs(q);

  for (const doc of querySnapshot.docs) {
    var itemdata = doc.data();

    newdata = [...newdata, itemdata];
  }

  return newdata[0];
};

const getServiceSchedule = async (serviceMail, dateString) => {
  console.log("getServiceSchedule from api called");
  const docSnap = await getDoc(
    doc(db, "ServiceAccountsDetails", serviceMail, "calendar", dateString)
  );
  var newdata = docSnap.data();

  if (newdata === undefined) {
    var data = {
      8: {},
      9: {},
      10: {},
      11: {},
      12: {},
      13: {},
      14: {},
      15: {},
      16: {},
      17: {},
      18: {},
    };
    setDoc(
      doc(db, "ServiceAccountsDetails", serviceMail, "calendar", dateString),
      data
    )
      .then(() => {
        console.log(
          "date doc added for: " + serviceMail + " date: " + dateString
        );
      })
      .catch((error) => {
        alert(error.message);
      });

    newdata = data;
  }
  return newdata;
};

const getAppoitment = async (clientMail, docName) => {
  console.log("getAppoitment from api called docname" + docName);
  const docSnap = await getDoc(
    doc(db, "ClientsAccountDetails", clientMail, "appoitments", docName)
  );

  var newdata = docSnap.data();
  console.log(newdata);
  return newdata;
};
const db = app.firestore();
const auth = firebase.auth();
const storage = getStorage();

export {
  db,
  auth,
  storage,
  getCars,
  getRequests,
  getRequestsScheduled,
  getRequestOffers,
  getServiceDetails,
  getServiceSchedule,
  getAppoitment,
};
