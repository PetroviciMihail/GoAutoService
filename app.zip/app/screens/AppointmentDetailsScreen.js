import React, { useEffect, useState } from "react";
import { View, StyleSheet, ScrollView } from "react-native";
import AppText from "../components/AppText";
import { auth, getAppoitment, getServiceDetails } from "../api/firebase";
import Screen from "../components/Screen";
import openMap from "react-native-open-maps";
import { ListItem2 } from "../components/lists";
import MapView, { Marker } from "react-native-maps";
import AppButton from "../components/AppButton";
function AppointmentDetailsScreen({ route, navigation }) {
  var request = route.params;
  const [appoitment, setAppoitment] = useState();
  const [service, setService] = useState();
  const [loaded, setLoaded] = useState(0);

  useEffect(() => {
    getAppoitmentDetailsFromDb();
  }, [loaded]);

  const getAppoitmentDetailsFromDb = async () => {
    getAppoitment(
      auth.currentUser.email,
      request.carVinNumber + request.timeadded
    )
      .then((result) => {
        setAppoitment(result);
        return getServiceDetails(result.serviceMail);
      })
      .then((result) => {
        setService(result);
        setLoaded(1);
      });
  };

  return (
    <Screen style={styles.container}>
      {loaded ? (
        <>
          <AppText style={styles.titleTag}>Appoitment date and hour</AppText>
          <ListItem2 title={appoitment.date + " " + appoitment.hour + ":00"} />

          <AppText style={styles.titleTag}>Price offered</AppText>
          <ListItem2 title={"$" + appoitment.price} />

          <AppText style={styles.titleTag}>At</AppText>
          <ListItem2 title={service.name} />
          <AppText style={styles.titleTag}>Adress</AppText>
          <ListItem2 title={service.adress} />
          <AppText style={styles.titleTag}>E-mail </AppText>
          <ListItem2 title={service.owner} />
          <AppText style={styles.titleTag}>Phone number </AppText>
          <ListItem2 title={service.phone} />

          <AppText style={styles.titleTag}>Location on map </AppText>
          <MapView
            style={styles.map}
            initialRegion={{
              latitude: service.lat,
              longitude: service.lng,
              latitudeDelta: 0.0922,
              longitudeDelta: 0.0421,
            }}
          >
            <Marker
              coordinate={{ latitude: service.lat, longitude: service.lng }}
            />
          </MapView>
          <AppButton
            color="medium"
            title={"Open in maps"}
            onPress={() => {
              openMap({
                latitude: service.lat,
                longitude: service.lng,
                zoom: 18,
              });
            }}
          />
        </>
      ) : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  container: {},
  map: {
    height: 400,
    width: 400,
    resizeMode: "contain",
  },
  titleTag: {
    paddingTop: 15,
    backgroundColor: "#eef2e1",
    width: "100%",
    padding: 5,
    fontSize: 22,
    textAlign: "center",
  },
});

export default AppointmentDetailsScreen;
