import React, { useEffect, useState } from "react";
import { View, StyleSheet, FlatList } from "react-native";
import AppButton from "../components/AppButton";
import AppText from "../components/AppText";
import Screen from "../components/Screen";
import { useIsFocused } from "@react-navigation/native";
import { collection, query, where, getDocs } from "firebase/firestore";
import { getStorage, ref, getDownloadURL } from "firebase/storage";

import colors from "../config/colors";
import { db, auth, storage, getRequestsScheduled } from "../api/firebase";

import RequestListItem from "../components/lists/RequestListItem";
import { ListItemDeleteAction } from "../components/lists";

function AppointmentsScreen({ navigation }) {
  //const getListingsApi = useApi(listingsApi.getListings);
  const [requestsdata, setrequestsData] = useState([]);
  const isFocused = useIsFocused();
  //console.log("am reincarcat toata faza");
  useEffect(() => {
    console.log("-----------------------------");
    getServiceRequestFromDB();
  }, [isFocused]);

  const getServiceRequestFromDB = async () => {
    const result = await getRequestsScheduled(auth.currentUser.email);
    console.log("service requests incarcate");
    setrequestsData(result);
    console.log(requestsdata);
  };

  return (
    <Screen style={styles.container}>
      {requestsdata.length ? (
        <View style={{ flex: 1 }}>
          <AppText style={styles.title}>My Appointments</AppText>
          <FlatList
            data={requestsdata}
            keyExtractor={(item) => item.timestamp}
            renderItem={({ item }) => (
              <RequestListItem
                category={item.category}
                title={item.carMake + " " + item.carModel}
                image={item.images[0]}
                subTitle={
                  !item.scheduled
                    ? "Offers: " + item.offers.length
                    : "Scheduled"
                }
                onPress={() => {
                  navigation.navigate("AppointmentDetails", item);
                }}
                renderRightActions={ListItemDeleteAction}
                subtitleStyle={
                  item.offers.length
                    ? { color: colors.brigthGreen }
                    : { color: colors.danger }
                }
              />
            )}
          />
        </View>
      ) : (
        <AppText style={styles.missingMessage}>No appointment yet</AppText>
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.backgroundColor,
  },
  title: {
    fontSize: 25,

    paddingTop: 20,
    color: colors.text,
    marginBottom: 15,
    textAlign: "center",
  },
  addbutton: {
    bottom: 10,
  },
  missingMessage: {
    flex: 1,
    textAlign: "center",
    textAlignVertical: "center",
  },
});

export default AppointmentsScreen;
