import React, { useEffect, useState } from "react";
import { View, StyleSheet } from "react-native";
import AppButton from "../components/AppButton";
import { getServiceDetails } from "../api/firebase";
import AppText from "../components/AppText";
import { ListItem2 } from "../components/lists";
import Screen from "../components/Screen";
import MapView, { Marker } from "react-native-maps";
import StarRating from "react-native-star-rating";
import openMap from "react-native-open-maps";
import colors from "../config/colors";

function ServiceDetailsScreen({ route, navigation }) {
  const { serviceMail, offer } = route.params;

  const [service, setService] = useState({});
  const [loaded, setLoaded] = useState(0);
  useEffect(() => {
    getServiceDetailsfromDB();
  }, []);

  const getServiceDetailsfromDB = async () => {
    const result = await getServiceDetails(serviceMail);
    setService(result);
    console.log(service);
    setLoaded(1);
  };
  return (
    <Screen>
      {loaded ? (
        <>
          <AppText style={styles.titleTag}>Bussines Name</AppText>
          <ListItem2 title={service.name} />
          <AppText style={styles.titleTag}>Adress</AppText>
          <ListItem2 title={service.adress} />
          <AppText style={styles.titleTag}>E-mail </AppText>
          <ListItem2 title={service.owner} />
          <AppText style={styles.titleTag}>Phone number </AppText>
          <ListItem2 title={service.phone} />
          <AppText style={styles.titleTag}>Rating</AppText>
          <View
            style={{
              width: "65%",
              alignSelf: "center",
              padding: 10,
            }}
          >
            <StarRating disabled maxStars={5} rating={4} starSize={25} />
          </View>
          <AppText style={styles.titleTag}>Location on map </AppText>
          <MapView
            style={styles.map}
            initialRegion={{
              latitude: service.lat,
              longitude: service.lng,
              latitudeDelta: 0.0922,
              longitudeDelta: 0.0421,
            }}
          >
            <Marker
              coordinate={{ latitude: service.lat, longitude: service.lng }}
            />
          </MapView>
          <AppButton
            color="medium"
            title={"Open in maps"}
            onPress={() => {
              openMap({
                latitude: service.lat,
                longitude: service.lng,
                zoom: 18,
              });
            }}
          />
          <AppButton
            color="secondary"
            title={"Schedule"}
            onPress={() => {
              navigation.push("ServiceSchedule", {
                service: service,
                offer: offer,
              });
            }}
          />
        </>
      ) : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  container: { alignItems: "center", flex: 1, width: "100%" },
  map: {
    height: 400,
    width: 400,
    resizeMode: "contain",
  },
  titleTag: {
    paddingTop: 15,
    backgroundColor: "#eef2e1",
    width: "100%",
    padding: 5,
    fontSize: 22,
    textAlign: "center",
  },
});

export default ServiceDetailsScreen;
