import React, { useEffect, useState } from "react";
import { View, StyleSheet, Dimensions } from "react-native";
import { auth, db } from "../api/firebase";
import {
  collection,
  query,
  where,
  getDocs,
  getDoc,
  setDoc,
  doc,
  onSnapshot,
} from "firebase/firestore";
import {
  LineChart,
  BarChart,
  PieChart,
  ProgressChart,
  ContributionGraph,
  StackedBarChart,
} from "react-native-chart-kit";
import Screen from "../components/Screen";
import AppText from "../components/AppText";

function CarStatisticsScreen({ route }) {
  const screenWidth = Dimensions.get("window").width;
  const chartConfig = {
    backgroundGradientFrom: "#000000",
    backgroundGradientFromOpacity: 0,
    backgroundGradientTo: "#000000",
    backgroundGradientToOpacity: 0.005,
    color: (opacity = 1) => `rgba(0, 62, 0, ${opacity})`,
    strokeWidth: 2, // optional, default 3
    barPercentage: 0.5,
    useShadowColorFromDataset: false, // optional
  };
  const car = route.params;
  const [data, setData] = useState({});
  const [graphData, setGrapfData] = useState({});
  const [loaded, setLoaded] = useState(0);

  useEffect(() => {
    getFromDb();
  }, []);

  const getFromDb = async () => {
    const q = query(
      collection(
        db,
        "ClientsAccountDetails",
        auth.currentUser.email,
        "appoitments"
      ),
      where("carVinNumber", "==", car.vinNumber),
      where("done", "==", true),
      where("canceled", "==", false)
    );

    var newdata = [];
    const querySnapshot = await getDocs(q);

    for (const doc of querySnapshot.docs) {
      var itemdata = doc.data();

      newdata = [...newdata, itemdata];
    }

    newdata.sort((a, b) => {
      if (a.date < b.date) return -1;
      if (a.date > b.date) return 1;
      return 0;
    });
    setData(newdata);

    console.log("chestii luate din appoitment");
    console.log(newdata);
    console.log("?");
    const data2 = {
      labels: newdata.map((item) => item.date),
      datasets: [
        {
          data: newdata.map((item) => parseInt(item.price)),
          color: (opacity = 1) => `rgba(128, 96, 0, ${opacity})`, // optional
          strokeWidth: 2, // optional
        },
      ],
      legend: ["Expenses"], // optional
    };
    setGrapfData(data2);
    console.log("data 22????");
    console.log(data2);
    setLoaded(1);
  };

  return (
    <Screen>
      <AppText style={{ textAlign: "center", marginTop: 20 }}>
        All time expense history
      </AppText>
      {loaded ? (
        <LineChart
          data={graphData}
          width={screenWidth}
          height={220}
          chartConfig={chartConfig}
          bezier
        />
      ) : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  container: {},
});

export default CarStatisticsScreen;
