import React, { useEffect, useState } from "react";
import { View, StyleSheet, Text, ScrollView } from "react-native";
import { Calendar, CalendarList, Agenda } from "react-native-calendars";
import { auth, getServiceSchedule } from "../api/firebase";
import AppText from "../components/AppText";
import HourListItem from "../components/lists/HourListItem";
import Constants from "expo-constants";
import {
  collection,
  query,
  where,
  getDocs,
  getDoc,
  setDoc,
  doc,
  updateDoc,
} from "firebase/firestore";
import { db } from "../api/firebase";
import colors from "../config/colors";
import AppButton from "../components/AppButton";
function ServiceScheduleScreen({ route, navigation }) {
  var { service, offer } = route.params;
  const [dateSelected, setDateSelected] = useState(null);
  const [hourSelected, setHourSelected] = useState(null);
  const [schedule, setSchedule] = useState();
  const [loaded, setLoaded] = useState(0);
  useEffect(() => {
    getServiceScheduleFromDB();
  }, [dateSelected]);

  const getServiceScheduleFromDB = async () => {
    const result = await getServiceSchedule(service.owner, dateSelected);
    console.log(result);
    setSchedule(result);
    setHourSelected(null);
    setLoaded(1);
  };

  const reserveHour = () => {
    var data = {};
    data[hourSelected] = {
      reserved: "reserved",
      client: auth.currentUser.email,
      carVinNumber: offer.carVinNumber,
      offerData: offer.data,
      requestTimeAdded: offer.timeadded,
    };

    updateDoc(
      doc(
        db,
        "ServiceAccountsDetails",
        service.owner,
        "calendar",
        dateSelected
      ),
      data
    )
      .then(() => {
        console.log(
          "date doc updated for " +
            service.owner +
            " date: " +
            dateSelected +
            " hour" +
            hourSelected
        );
      })
      .catch((error) => {
        alert(error.message);
      });

    updateRequest();
    saveAppoitement(hourSelected);
  };

  const updateRequest = () => {
    var docName = offer.carVinNumber + offer.timeadded;
    var data = {
      scheduled: true,
    };
    updateDoc(doc(db, "ServiceRequests", docName), data)
      .then(() => {
        console.log("Request scheduled");
      })
      .catch((error) => {
        alert(error.message);
      });
  };
  const saveAppoitement = (hour) => {
    var docName = offer.carVinNumber + offer.timeadded;
    var data = {
      serviceName: service.name,
      serviceAdress: service.adress,
      serviceMail: service.owner,
      price: offer.price,
      requestDocName: offer.carVinNumber + offer.timeadded,
      date: dateSelected,
      hour: hour,
      km: 0,
      done: false,
      carVinNumber: offer.carVinNumber,
      canceled: false,
      docName: docName,
    };
    setDoc(
      doc(
        db,
        "ClientsAccountDetails",
        auth.currentUser.email,
        "appoitments",
        docName
      ),
      data
    )
      .then(() => {
        console.log("appoitment added");
      })
      .catch((error) => {
        alert(error.message);
      });
  };

  return (
    <View style={styles.container}>
      <Calendar
        // Minimum date that can be selected, dates before minDate will be grayed out. Default = undefined
        minDate={Date.now()}
        // Handler which gets executed on day press. Default = undefined
        onDayPress={(day) => {
          var date = new Date(day.dateString);
          if (date.getDay() != 0 && date.getDay() != 6) {
            setLoaded(0);
            setDateSelected(day.dateString);
            console.log(day);
            console.log("selected day", day);
          }
        }}
        hideExtraDays={true}
        // Month format in calendar title. Formatting values: http://arshaw.com/xdate/#Formatting
        monthFormat={"yyyy MM"}
        // Handler which gets executed when visible month changes in calendar. Default = undefined
        onMonthChange={(month) => {
          console.log("month changed", month);
        }}
        // If firstDay=1 week starts from Monday. Note that dayNames and dayNamesShort should still start from Sunday
        firstDay={1}
        // Handler which gets executed when press arrow icon left. It receive a callback can go back month
        onPressArrowLeft={(subtractMonth) => subtractMonth()}
        // Handler which gets executed when press arrow icon right. It receive a callback can go next month
        onPressArrowRight={(addMonth) => addMonth()}
        // Disable all touch events for disabled days. can be override with disableTouchEvent in markedDates
        disableAllTouchEventsForDisabledDays={true}
        // Enable the option to swipe between months. Default = false
        enableSwipeMonths={true}
      />
      {dateSelected && loaded ? (
        <ScrollView
          contentContainerStyle={{
            alignItems: "center",
            marginBottom: 15,
            marginTop: 15,
          }}
        >
          <HourListItem
            schedule={schedule}
            hour={"8"}
            selectedHour={hourSelected}
            onPress={() => {
              console.log("8 apasat");
              setHourSelected("8");
            }}
          />
          <HourListItem
            schedule={schedule}
            hour={"9"}
            selectedHour={hourSelected}
            onPress={() => {
              console.log("9 apasat");
              setHourSelected("9");
            }}
          />
          <HourListItem
            schedule={schedule}
            hour={"10"}
            selectedHour={hourSelected}
            onPress={() => {
              setHourSelected("10");
            }}
          />
          <HourListItem
            schedule={schedule}
            hour={"11"}
            selectedHour={hourSelected}
            onPress={() => {
              setHourSelected("11");
            }}
          />
          <HourListItem
            schedule={schedule}
            hour={"12"}
            selectedHour={hourSelected}
            onPress={() => {
              setHourSelected("12");
            }}
          />
          <HourListItem
            schedule={schedule}
            hour={"13"}
            selectedHour={hourSelected}
            onPress={() => {
              setHourSelected("13");
            }}
          />
          <HourListItem
            schedule={schedule}
            hour={"14"}
            selectedHour={hourSelected}
            onPress={() => {
              setHourSelected("14");
            }}
          />
          <HourListItem
            schedule={schedule}
            hour={"15"}
            selectedHour={hourSelected}
            onPress={() => {
              setHourSelected("15");
            }}
          />
          <HourListItem
            schedule={schedule}
            hour={"16"}
            selectedHour={hourSelected}
            onPress={() => {
              setHourSelected("16");
            }}
          />
          <HourListItem
            schedule={schedule}
            hour={"17"}
            selectedHour={hourSelected}
            onPress={() => {
              setHourSelected("17");
            }}
          />
          <HourListItem
            schedule={schedule}
            hour={"18"}
            selectedHour={hourSelected}
            onPress={() => {
              setHourSelected("18");
            }}
          />
        </ScrollView>
      ) : (
        <AppText style={{ textAlign: "center", marginTop: 40 }}>
          select a date to show hourly schedule
        </AppText>
      )}
      {hourSelected && (
        <AppButton
          title="Confirm"
          color="secondary"
          onPress={() => {
            reserveHour();
            alert("Apoitment added!");
            navigation.navigate("MyRequests");
          }}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingTop: Constants.statusBarHeight,
    backgroundColor: colors.backgroundColor,
    padding: 5,
    flex: 1,
  },
});

export default ServiceScheduleScreen;
