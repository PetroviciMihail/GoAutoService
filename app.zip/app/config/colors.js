export default {
  primary: "#F2605",
  secondary: "#54900F",
  black: "#000",
  white: "#fff",
  medium: "#797a5c",
  light: "#e0db5a", //#D6CE15
  dark: "#1F2605",
  backgroundColor: "#eef2e9",
  danger: "#ff5252",
  text: "#53543f",
  brigthGreen: "#6fd22e",
};
